/*
 File: ContFramePool.C
 
 Author:
 Date  : 
 
 */

/*--------------------------------------------------------------------------*/
/* 
 POSSIBLE IMPLEMENTATION
 -----------------------

 The class SimpleFramePool in file "simple_frame_pool.H/C" describes an
 incomplete vanilla implementation of a frame pool that allocates 
 *single* frames at a time. Because it does allocate one frame at a time, 
 it does not guarantee that a sequence of frames is allocated contiguously.
 This can cause problems.
 
 The class ContFramePool has the ability to allocate either single frames,
 or sequences of contiguous frames. This affects how we manage the
 free frames. In SimpleFramePool it is sufficient to maintain the free 
 frames.
 In ContFramePool we need to maintain free *sequences* of frames.
 
 This can be done in many ways, ranging from extensions to bitmaps to 
 free-lists of frames etc.
 
 IMPLEMENTATION:
 
 One simple way to manage sequences of free frames is to add a minor
 extension to the bitmap idea of SimpleFramePool: Instead of maintaining
 whether a frame is FREE or ALLOCATED, which requires one bit per frame, 
 we maintain whether the frame is FREE, or ALLOCATED, or HEAD-OF-SEQUENCE.
 The meaning of FREE is the same as in SimpleFramePool. 
 If a frame is marked as HEAD-OF-SEQUENCE, this means that it is allocated
 and that it is the first such frame in a sequence of frames. Allocated
 frames that are not first in a sequence are marked as ALLOCATED.
 
 NOTE: If we use this scheme to allocate only single frames, then all 
 frames are marked as either FREE or HEAD-OF-SEQUENCE.
 
 NOTE: In SimpleFramePool we needed only one bit to store the state of 
 each frame. Now we need two bits. In a first implementation you can choose
 to use one char per frame. This will allow you to check for a given status
 without having to do bit manipulations. Once you get this to work, 
 revisit the implementation and change it to using two bits. You will get 
 an efficiency penalty if you use one char (i.e., 8 bits) per frame when
 two bits do the trick.
 
 DETAILED IMPLEMENTATION:
 
 How can we use the HEAD-OF-SEQUENCE state to implement a contiguous
 allocator? Let's look a the individual functions:
 
 Constructor: Initialize all frames to FREE, except for any frames that you 
 need for the management of the frame pool, if any.
 
 get_frames(_n_frames): Traverse the "bitmap" of states and look for a 
 sequence of at least _n_frames entries that are FREE. If you find one, 
 mark the first one as HEAD-OF-SEQUENCE and the remaining _n_frames-1 as
 ALLOCATED.

 release_frames(_first_frame_no): Check whether the first frame is marked as
 HEAD-OF-SEQUENCE. If not, something went wrong. If it is, mark it as FREE.
 Traverse the subsequent frames until you reach one that is FREE or 
 HEAD-OF-SEQUENCE. Until then, mark the frames that you traverse as FREE.
 
 mark_inaccessible(_base_frame_no, _n_frames): This is no different than
 get_frames, without having to search for the free sequence. You tell the
 allocator exactly which frame to mark as HEAD-OF-SEQUENCE and how many
 frames after that to mark as ALLOCATED.
 
 needed_info_frames(_n_frames): This depends on how many bits you need 
 to store the state of each frame. If you use a char to represent the state
 of a frame, then you need one info frame for each FRAME_SIZE frames.
 
 A WORD ABOUT RELEASE_FRAMES():
 
 When we releae a frame, we only know its frame number. At the time
 of a frame's release, we don't know necessarily which pool it came
 from. Therefore, the function "release_frame" is static, i.e., 
 not associated with a particular frame pool.
 
 This problem is related to the lack of a so-called "placement delete" in
 C++. For a discussion of this see Stroustrup's FAQ:
 http://www.stroustrup.com/bs_faq2.html#placement-delete
 
 */
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/
#define MB * (0x1 << 20)
#define KB * (0x1 << 10)


/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "cont_frame_pool.H"
#include "console.H"
#include "utils.H"
#include "assert.H"

/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/
ContFramePool* ContFramePool::head_pool;
ContFramePool* ContFramePool::list_pool;

/* -- (none) -- */

/* 
 * 10 - Head of frame
 * 11 - ALLOCATED
 * 00 - FREE
 * 01 - Inaccessible
 */

/*--------------------------------------------------------------------------*/
/* METHODS FOR CLASS   C o n t F r a m e P o o l */
/*--------------------------------------------------------------------------*/

ContFramePool::ContFramePool(unsigned long _base_frame_no,
                             unsigned long _n_frames,
                             unsigned long _info_frame_no,
                             unsigned long _n_info_frames)
{
    // initialising the variables
    base_frame_no = _base_frame_no;
    nframes = _n_frames;
    n_free_frames = _n_frames;
    
    info_frame_no = _info_frame_no;
    n_info_frames = _n_info_frames;
    assert ((nframes % 4 ) == 0);

    if(info_frame_no == 0) {
      //  if the frame to store the managing information of pool is not specified
      // we initialise the bitmap in this frame pool itself
        bitmap = (unsigned char *) (base_frame_no * FRAME_SIZE); 
    } else {
        bitmap = (unsigned char *) (info_frame_no * FRAME_SIZE);
    }

    // as we need two bits for each frame in the pool, we initialise the size of bitmap accordingly
    // marking the bits of bitmap as 0x00
    for (int j=0; j < nframes/4;j++){
      bitmap[j] = 0x00;
    }
    if (info_frame_no==0){
      bitmap[0]=0x80;
      // putting the first frame to head
      n_free_frames = n_free_frames-1;
    }

    if (ContFramePool::head_pool==NULL){
      ContFramePool::head_pool=this;
      ContFramePool::list_pool = this;
      // if the pool list is not initialised and head is null, make this frame pool the head
    }else{
      ContFramePool::list_pool->next_pool=this;
      list_pool = this;
    }
    next_pool=NULL;



    
}

unsigned long ContFramePool::get_frames(unsigned int _n_frames)
{
    
    unsigned int frames_needed = _n_frames;
    
    unsigned int head_frame = base_frame_no;
    unsigned int free_continuous_frames = 0;
    int flag = 0;

    unsigned char check_if_free_mask[] = {0xC0,0x30,0xC,0x3};
    // this is a mask array used to check whether the state of the frame in bitmap is free or not
    
    int found = 0;
    
    if(n_free_frames<frames_needed) {
      // if there are less free frames than frames needed, function returns zero
      Console::puts("needed frames are less than available frames");
      Console::puts("n_free_frames = "); Console::puti(n_free_frames);Console::puts("\n");
      Console::puts("_n_frames = "); Console::puti(_n_frames);Console::puts("\n");
      return 0;
    }

    for (int frame_iterator=0; frame_iterator<nframes;frame_iterator++){
      unsigned int bitmap_index_i = frame_iterator/4;
      unsigned int bitmap_index_j = frame_iterator%4;

      if (found==0){
        head_frame = base_frame_no+frame_iterator;
      }

      if (bitmap[bitmap_index_i]&check_if_free_mask[bitmap_index_j]==0x00){
        found = found+1;
      }else{
        found = 0;
      }

      if (found == frames_needed){
        flag=1;
        break;
      }

      unsigned char update_head_mask[] = {0x80,0x20,0x8,0x2};
      unsigned char update_used_mask[] = {0xC0,0x30,0xC,0x3};


      if (flag==1){
        
        for (int iter = 0; iter<found;iter++){
          unsigned int frame_no = head_frame + iter - base_frame_no;

          unsigned int bitmap_index_i = frame_no/4;
          unsigned int bitmap_index_j = frame_no%4;
          if (frame_no==head_frame){
            
            bitmap[bitmap_index_i] = bitmap[bitmap_index_i] | update_head_mask[bitmap_index_j];}else{
              bitmap[bitmap_index_i] = bitmap[bitmap_index_i] | update_used_mask[bitmap_index_j];
            }


        }
        n_free_frames = n_free_frames - frames_needed;
        return head_frame;
      }
      else{
        Console::puts("No free frame found for length: ");Console::puti(_n_frames);Console::puts("\n");
        return 0;
      }

    }
    //assert(false);
}

void ContFramePool::mark_inaccessible(unsigned long _base_frame_no,
                                      unsigned long _n_frames)
{
  unsigned long inaccessible_start = _base_frame_no;
  if (_base_frame_no < base_frame_no || base_frame_no + nframes < _base_frame_no + _n_frames) {
        Console::puts("range out of index, cannot mark inaccessible \n");}
  else{
    n_free_frames = n_free_frames - _n_frames;
    unsigned char update_inaccesible_mask[] = {0x7F , 0xDF , 0xF7, 0xFD};
    // inaccesible mask = {01111111, 11011111, 11110111, 11111101}
    // inaccessible mask is used to update the frame state to inaccesible in the bitmap pointer

    for (int frame_iterator=0; frame_iterator<_n_frames;frame_iterator++){
      unsigned int frame_no = frame_iterator+inaccessible_start-base_frame_no;
      unsigned int bitmap_index_i = frame_iterator/4;
      unsigned int bitmap_index_j = frame_iterator%4;
      bitmap[bitmap_index_i] = bitmap[bitmap_index_i] & update_inaccesible_mask[bitmap_index_j];
    }
  }
}

void ContFramePool::release_frames(unsigned long _first_frame_no)
{
  //finding the pool this belongs to
  ContFramePool* pool_current = ContFramePool::head_pool;

  while ((pool_current->base_frame_no>_first_frame_no)||(pool_current->base_frame_no+pool_current->nframes<=_first_frame_no)){
    if (pool_current->next_pool==NULL){
      Console::puts("given frame not found. cannot release frame hence. \n");
      return;
    }else{
      pool_current = pool_current->next_pool;
    }
  }
  // this while loop is used to find out the frame pool that the input frame belongs to

  unsigned char* current_bitmap = pool_current->bitmap;
  unsigned int frames_no_current_pool = _first_frame_no - pool_current->base_frame_no;

  unsigned int bitmap_index_head_i = frames_no_current_pool/4;
  unsigned int bitmap_index_head_j = frames_no_current_pool%4;





  unsigned char frames_freeing_mask[]={0x3F,0xCF,0xF3,0xFC};
  // frames_freeing_mask = {00111111, 11001111 ,11110011, 11111100} used to change frame state to free
  unsigned char show_two_bits[] = {0xC0,0x30,0xC,0x3};
  // show_two_bits = {11000000, 0011000000, 00001100 , 00000011 } used to make all bits zero except the bits in 1's position
  unsigned char head_check_result[]={0x80,0x20,0x8,0x2};
  // head_check_result = {10000000 , 00100000, 00001000, 00000010} used to check whether a frame state is head
  unsigned char used_bits_check_result[] = {0xC0,0x30,0xC,0x3};
  // used_bits_check_result = {11000000, 00110000 ,00001100 , 00000011 } used to check whether a frame is in use

  if (current_bitmap[bitmap_index_head_i]& show_two_bits[bitmap_index_head_j] == head_check_result[bitmap_index_head_j]){
    // if the given frame is a head, free up the head frame. else return
    current_bitmap[bitmap_index_head_i]=current_bitmap[bitmap_index_head_j]&frames_freeing_mask[bitmap_index_head_j];
    pool_current->n_free_frames = pool_current->n_free_frames+1;

    for (int frame_iterator=frames_no_current_pool+1 ; frame_iterator<pool_current->nframes;frame_iterator++){
    // iterate from the frame next to head frame. if the frame is used, it is freed
    
    
    unsigned int bitmap_index_i = frame_iterator/4;
    unsigned int bitmap_index_j = frame_iterator%4;

    if (current_bitmap[bitmap_index_i]&show_two_bits[bitmap_index_j]==used_bits_check_result[bitmap_index_j]){
      current_bitmap[bitmap_index_i]=current_bitmap[bitmap_index_i]&frames_freeing_mask[bitmap_index_j];
      pool_current->n_free_frames = pool_current->n_free_frames+1;
    }else{
      // if we come accross a frame that is in a state other than used, we break the for loop and return
      break;
    }
    return; // all frames released
  }}
  else{
    Console::puts("Frame not head of sequence, cannot release \n");
    return;

  }


}

unsigned long ContFramePool::needed_info_frames(unsigned long _n_frames)
{
  // returns the number of frames needed to store the management information of given number of frames
  return  _n_frames/8 +(_n_frames % 8 > 0 ? 1 : 0);
}
